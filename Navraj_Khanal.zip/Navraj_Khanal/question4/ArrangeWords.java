import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays; 


public class ArrangeWords {
    public static void main(String[] args) {
        BufferedReader reader;  
        String[] temp = {};
         String input="";
        String duplicate=" ";
        String unique = " ";
        String eliminated=" ";
        
  try {
   reader = new BufferedReader(new FileReader("input_sentence.txt")); //Reading the file from given path
   String line = reader.readLine();
   while (line != null) {
    //System.out.println(line);
    input=line;
    line = reader.readLine();
                                
   }
   reader.close();
  } catch (IOException e) {
  }
                
             temp = input.split(" ");  //Separating the words by avoiding space
             int n=temp.length;     //Storing the length of words.
             int count=0;

      for(int i=0; i<n; i++)
      {
          count=1;
          for(int j=i+1; j<n;j++)
          {
              if(temp[i].equals(temp[j]))
              {
                  count++;
                 //Set temp[j] to "0" to avoid printing the visited items
                  temp[j]="0";
                 

              }
              
      }
          if(count>1 && temp[i]!="0")  //Checking condition for duplicate words by count
          {
              duplicate= duplicate+(temp[i] + " - " + count+ " ");
              eliminated = eliminated+ temp[i]+" ";  //Storing the single words for single unique word-line
          }
          else if(count==1 && temp[i]!="0") {  //Checking condition for unique words
              unique= unique+temp[i]+", ";
              eliminated= eliminated+ temp[i]+" "; //Storing the unique words for single unique word-line
          }
          
            
}
        System.out.println("unique words: "+unique);
        System.out.println("dublicate words: "+duplicate);
        System.out.println("eliminated words: "+ eliminated);

}
}
