/*Progra to read numbers from file and write sorted numbers to another file*/ 
import java.io.IOException;
import java.util.Arrays; 
import java.io.*;


public class FileSorting {
    public static void main(String[] args) throws FileNotFoundException {
        BufferedReader reader;
        BufferedWriter bufferedWriter;
        FileWriter fileWriter;
        String[] temp = {};
        String input="";
        String output="";
        
        
  try {
   reader = new BufferedReader(new FileReader("input_numbers.txt"));//Reading path declared
   String line = reader.readLine();
   while (line != null) {
    input=line;
    line = reader.readLine();
                                
   }
              input= input.replaceAll("\\[", "");   
              input= input.replaceAll("\\]", "");
              temp = input.split(", ");
              int finalArray[]=new int[temp.length];
              for(int i=0; i<temp.length;i++)
             {
                 finalArray[i]= Integer.parseInt(temp[i]);   /*Converting the numbers to integer for sorting operation*/
                 
             }
              Arrays.sort(finalArray);   /*ArraySorting method*/
              output = "";
              for(int i=0; i<finalArray.length-1;i++)
              {
                   
                  output = output+finalArray[i]+", ";   /*Storing the sorted array in string so as to write it into file*/
             }
              output = output+finalArray[finalArray.length-1];
            //  System.out.println(output); /*Use to print sorted numbers in console*/
     
   reader.close();
  } catch (IOException e) {
  }
              
              try{
        fileWriter=new FileWriter("output_numbers.txt");    
        bufferedWriter = new BufferedWriter(fileWriter);
    
    fileWriter.write(output);
    fileWriter.flush();   /*File operation flushed for next writing*/
    fileWriter.close();    /*File closed after file operation*/
}
                catch (IOException e) {
             System.out.println("Error: "+e);
}
 
}

}
