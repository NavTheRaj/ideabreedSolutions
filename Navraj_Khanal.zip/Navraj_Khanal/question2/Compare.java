/*Program to compare array-number and pure number*/
import java.util.Scanner;
import java.io.*;
import java.util.Arrays;

class Compare{
  public static void main(String[] args){
    int arr[]=new int[5];
    int num=0;
    Scanner sc=new Scanner(System.in);
    System.out.print("Enter any 5 digits in array");   /*User input numbers in an array*/
    for(int i=0;i<5;i++)
    {
      arr[i]=sc.nextInt();
    }
     System.out.print("Enter 5 digits number");   /*User input number of digit equals to array length for compare*/
     num=sc.nextInt();
   int result= compareNum(arr,num);      /* Passing array and number to method compareNum*/
   System.out.println("Return value: " +result);
  }
  public static int compareNum(int a[],int temp)
  {
       String join="";
       for(int i=0;i<a.length;i++){
       join=join+a[i];                                      /*Converting array numbers to single form but still as string*/
    }
   
    if(Integer.parseInt(join)==temp)     /*String converted to integer so as to compare integers*/
     return 1;   /*Returning 1 if array-number and pure number are same*/
    else     /*Else 0 returned */
      return 0;
  }
}
                                         